import React, { Component } from "react"
import Buy from "./Buy";
class Row extends Component {
    constructor(props) {
        super(props);
        console.log("ELEMENTOS",this.props.element)
    }

    render() {
        return (
            <tr>
                {Object.values(this.props.element).map(key => this.present(key))}
                <Buy product ={this.props.element}/>
            </tr>
        )
    }

    present(key){
        if(typeof key === 'string'){
            if(key.length > 100){
                return <td>{key.slice(0,100)}<br></br><button>More...</button></td>
            }
            else{
                return <td>{key}</td>
            }
        }
        else{
            return <td>{key}</td>
        }
    }
}
export default Row;
