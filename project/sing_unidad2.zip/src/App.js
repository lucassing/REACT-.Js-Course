import './App.css';
// import Register from "./Register"
import ProductTable from "./ProductTable";
function App() {
  return (
    <div className="App">
        {/*{<Register />}*/}
        {<ProductTable/>}
    </div>
  );
}

export default App;
