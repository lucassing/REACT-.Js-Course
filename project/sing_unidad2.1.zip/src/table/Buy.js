import React, { Component } from "react"
class Buy extends Component {
    constructor(props) {
        super(props);
        this.state = {
            visibleBuyMessage:false,
        }
        this.buyMessage = 'Gracias por su compra! Producto SKU:'
    }

    delay = ms => new Promise(res => setTimeout(res, ms));

    showOnOff = async (value) => {
        await this.delay(value);
        this.setState({visibleBuyMessage:false})
    }

    buyPressed = async ()=>{
        this.setState({visibleBuyMessage:true},()=>{
          this.showOnOff(2000)
        })
    }

    render() {
        return (
            <div>
                <button onClick={this.buyPressed}>Buy!</button>
                <tr hidden={!this.state.visibleBuyMessage}>{this.buyMessage+this.props.product.sku}</tr>
            </div>
        )
    }
}
export default Buy;
