import React, { Component } from "react"
class Headers extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <tr>
                {Object.keys(this.props.titles).map(key=><th>{key.toUpperCase()}</th>)}
                <th>Buy</th>
            </tr>
        )
    }
}
export default Headers;
