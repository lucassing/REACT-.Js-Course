import React, { Component } from "react"
import Buy from "./Buy";
class Row extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <tr>
                {Object.values(this.props.element).map(key => <td>{key}</td>)}
                <Buy product ={this.props.element}/>
            </tr>
        )
    }
}
export default Row;
