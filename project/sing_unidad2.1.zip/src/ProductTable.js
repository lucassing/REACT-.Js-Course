import React, { Component } from "react"
import Row from "./table/Row";
import Headers from "./table/Headers";
import Buy from "./table/Buy";
const list_products = [
    {
        'nombre': 'Manzana',
        'descripcion': 'bla bal bla',
        'precio': '500$',
        'sku': '1',
        'qty': 10,
    },
    {
        'nombre': 'Pera',
        'descripcion': 'bla bal bla s',
        'precio': '200$',
        'sku': '2',
        'qty': 20
    },
    {
        'nombre': 'Banana',
        'descripcion': 'bla bal bla s',
        'precio': '200$',
        'sku': '3',
        'qty': 30
    },
    {
        'nombre': 'Sandia',
        'descripcion': 'bla bal bla s',
        'precio': '200$',
        'sku': '4',
        'qty': 40
    }
]

class ProductTable extends Component {
    constructor() {
        super(Component)
        this.state = {
            'filter':{
                'value': 9,
            },
            'products': list_products
        }
    }
    toInitial = (event)=>{
        this.setState({products:list_products,
            filter:{'value':event.target.value}},()=>this.priceFilter(event))
    }

    priceFilter = (event)=>{
        let product = this.state.products.filter(function (product){
            return product.qty>this.state.filter.value
        }, this)
        this.setState({products:product})
    }

    render() {
        return (
        <table>
            <Headers titles={this.state.products[0]}/>
            {this.state.products.map(producto => <Row element = {producto}/>)}
            <label htmlFor="filter">Qty Filter:</label>
            <input type="number" value={this.state.filter.value} onChange={this.toInitial} id='filter'/>
        </table>
        )
    }
}
export default ProductTable;
