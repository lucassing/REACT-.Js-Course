export const endpoint =  "https://my-json-server.typicode.com/lucassing/REACT-.Js-Course/"
