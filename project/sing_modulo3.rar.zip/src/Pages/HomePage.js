import React from "react"
import ProductTablePage from "./ProductTablePage";

function HomePage(){
    return(
        <div>
            <h3>Welcome to Market Istambul</h3>
            <ProductTablePage></ProductTablePage>
        </div>
    )
}
export default HomePage
