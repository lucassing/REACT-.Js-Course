import React,{Component} from "react"
import "./RegisterElement.css"
class RegisterElement extends Component{
    render(){
        return(
        <div class='row'>
            <label class='col'>{this.props.label}</label>
            <input class='col' type={this.props.type}/>
        </div>
        )
    }
}
export default RegisterElement;