import React from "react"

function Home(){
    return(
        <div>
            <h3>Bienvenido a MarketIstambul.com</h3>
        </div>
    )
}
export default Home
